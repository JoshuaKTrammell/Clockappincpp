
/*
Joshua Trammell
07/21/2024
*/

#ifndef CLOCKS_H
#define CLOCKS_H

#include <iostream>
#include <iomanip>
#include <string>
#include <limits>

using namespace std;

// Global variable declarations
extern unsigned int hour;
extern unsigned int minute;
extern unsigned int second;

// Function declarations
string twoDigitString(unsigned int n);
string nCharString(size_t n, char c);
string formatTime24(unsigned int h, unsigned int m, unsigned int s);
string formatTime12(unsigned int h, unsigned int m, unsigned int s);
void clearInput();
void printMenu(const string menu[], size_t size, size_t width);
void getTime24();
unsigned int getMenuChoice(unsigned int maxChoice);
void displayClocks(unsigned int h, unsigned int m, unsigned int s);
void setHour(unsigned int h);
unsigned int getHour();
void setMinute(unsigned int m);
unsigned int getMinute();
void setSecond(unsigned int s);
unsigned int getSecond();
void addOneHour();
void addOneMinute();
void addOneSecond();
void displayMenu();
void mainMenu();


#endif // CLOCK_H
